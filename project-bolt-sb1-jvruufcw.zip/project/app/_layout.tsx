import { useEffect } from 'react';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { StripeProvider } from '@stripe/stripe-react-native';

const STRIPE_PUBLIC_KEY = 'your_stripe_public_key';

export default function RootLayout() {
  return (
    <StripeProvider publishableKey={STRIPE_PUBLIC_KEY}>
      <Stack screenOptions={{ 
        headerStyle: { backgroundColor: '#000' },
        headerTintColor: '#fff',
        headerTitleStyle: { color: '#fff' }
      }}>
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        <Stack.Screen name="(auth)" options={{ headerShown: false }} />
      </Stack>
      <StatusBar style="light" />
    </StripeProvider>
  );
}