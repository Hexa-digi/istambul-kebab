import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { useState } from 'react';

const categories = [
  { id: 1, name: 'Sandwichs' },
  { id: 2, name: 'Assiettes' },
  { id: 3, name: 'Boissons' },
  { id: 4, name: 'Desserts' },
];

const menuItems = [
  {
    id: 1,
    name: 'Kebab Classique',
    price: 7.50,
    category: 'Sandwichs',
    image: 'https://images.unsplash.com/photo-1633321702518-7feccafb94d5?auto=format&fit=crop&q=80&w=400',
  },
  {
    id: 2,
    name: 'Assiette Mixte',
    price: 12.90,
    category: 'Assiettes',
    image: 'https://images.unsplash.com/photo-1529006557810-274b9b2fc783?auto=format&fit=crop&q=80&w=400',
  },
  // Add more menu items...
];

export default function MenuScreen() {
  const [selectedCategory, setSelectedCategory] = useState('Sandwichs');

  return (
    <View style={styles.container}>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categories}>
        {categories.map((category) => (
          <TouchableOpacity
            key={category.id}
            style={[
              styles.categoryButton,
              selectedCategory === category.name && styles.categoryButtonActive,
            ]}
            onPress={() => setSelectedCategory(category.name)}
          >
            <Text style={[
              styles.categoryText,
              selectedCategory === category.name && styles.categoryTextActive,
            ]}>
              {category.name}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <ScrollView style={styles.menuList}>
        {menuItems
          .filter(item => item.category === selectedCategory)
          .map(item => (
            <TouchableOpacity key={item.id} style={styles.menuItem}>
              <Image source={{ uri: item.image }} style={styles.menuImage} />
              <View style={styles.menuItemContent}>
                <Text style={styles.menuItemName}>{item.name}</Text>
                <Text style={styles.menuItemPrice}>{item.price.toFixed(2)} €</Text>
              </View>
            </TouchableOpacity>
          ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#111',
  },
  categories: {
    padding: 10,
  },
  categoryButton: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    marginRight: 10,
    borderRadius: 20,
    backgroundColor: '#222',
  },
  categoryButtonActive: {
    backgroundColor: '#ff0000',
  },
  categoryText: {
    color: '#fff',
    fontSize: 16,
  },
  categoryTextActive: {
    color: '#fff',
    fontWeight: 'bold',
  },
  menuList: {
    padding: 15,
  },
  menuItem: {
    backgroundColor: '#222',
    borderRadius: 10,
    marginBottom: 15,
    overflow: 'hidden',
  },
  menuImage: {
    width: '100%',
    height: 200,
  },
  menuItemContent: {
    padding: 15,
  },
  menuItemName: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  menuItemPrice: {
    color: '#ff0000',
    fontSize: 16,
    fontWeight: 'bold',
  },
});